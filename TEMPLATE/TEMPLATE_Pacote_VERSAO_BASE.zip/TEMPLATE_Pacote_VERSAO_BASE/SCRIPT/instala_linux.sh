sqlplus /nolog @./ordem_instalacao_linux.sql
